"""
Fake Job Posting Detector — Feature Engineering

Turns the raw Kaggle "Real / Fake Job Postings" CSV into a model-ready
feature set, based on patterns found during EDA:

  - Fake postings are far more likely to be missing a company profile
    (67.8% vs 16.0% for real postings) and less likely to have a company
    logo (33% vs 82%).
  - Certain phrases ("work from home", "no experience") appear far more
    often in fake postings (10-20x higher rate) than real ones.

Run: python data_prep.py
Output: processed_data.csv (features + target, ready for train.py)
"""
import pandas as pd
import re

RED_FLAG_PHRASES = [
    "urgent", "immediate", "work from home", "no experience",
    "earn money", "easy money",
]


def load_raw(path: str = "fake_job_postings.csv") -> pd.DataFrame:
    return pd.read_csv(path)


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # --- Structural / missingness features ---
    df["company_profile_missing"] = df["company_profile"].isnull().astype(int)
    df["salary_missing"] = df["salary_range"].isnull().astype(int)
    df["requirements_missing"] = df["requirements"].isnull().astype(int)
    df["benefits_missing"] = df["benefits"].isnull().astype(int)

    # has_company_logo, has_questions, telecommuting already exist as 0/1

    # --- Text length features ---
    df["description_length"] = df["description"].fillna("").str.len()
    df["requirements_length"] = df["requirements"].fillna("").str.len()

    # --- Keyword / red-flag features ---
    combined_text = (
        df["title"].fillna("") + " " +
        df["description"].fillna("") + " " +
        df["requirements"].fillna("")
    ).str.lower()

    for phrase in RED_FLAG_PHRASES:
        col_name = "kw_" + re.sub(r"\s+", "_", phrase)
        df[col_name] = combined_text.str.contains(phrase, regex=False).astype(int)

    # --- Simple categorical encodings ---
    df["employment_type"] = df["employment_type"].fillna("Unknown")
    df["required_experience"] = df["required_experience"].fillna("Unknown")

    return df


def build_feature_table(df: pd.DataFrame) -> pd.DataFrame:
    """Select the final columns that go into the model."""
    feature_cols = [
        "telecommuting", "has_company_logo", "has_questions",
        "company_profile_missing", "salary_missing",
        "requirements_missing", "benefits_missing",
        "description_length", "requirements_length",
    ] + [c for c in df.columns if c.startswith("kw_")]

    categorical_cols = ["employment_type", "required_experience"]

    X = df[feature_cols + categorical_cols].copy()
    X = pd.get_dummies(X, columns=categorical_cols, drop_first=True)

    y = df["fraudulent"]

    result = X.copy()
    result["fraudulent"] = y
    result["job_id"] = df["job_id"]  # kept for company-aware splitting later
    return result


if __name__ == "__main__":
    raw = load_raw()
    engineered = engineer_features(raw)
    final = build_feature_table(engineered)
    final.to_csv("processed_data.csv", index=False)
    print(f"Saved processed_data.csv with shape {final.shape}")
    print(f"Fraud rate: {final['fraudulent'].mean() * 100:.2f}%")
